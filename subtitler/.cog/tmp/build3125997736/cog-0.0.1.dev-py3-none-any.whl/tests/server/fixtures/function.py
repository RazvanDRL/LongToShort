def predict(text: str) -> str:
    return "hello " + text
